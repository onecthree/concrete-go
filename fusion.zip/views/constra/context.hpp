#pragma once

#include <phpcpp.h>

// class constra : public Php::Base {
//     public: void static require(std::string src) {
//         Php::require_once(src);
//     }
// };