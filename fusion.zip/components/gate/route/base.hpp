#pragma once

#include <phpcpp.h>

class RouteBase : public Php::Base {
    
    // constructor
    public: RouteBase() {
        
    }

    public: void Method() {

    }

    public: void Uri() {

    }

    public: void Action() {

    }

    public: void Attach() {

    }
};