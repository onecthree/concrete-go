# Fusion

### A PHP Framework written in C++ using PHP-CPP. Used for SIDIKAH-Project gateway-logic.

For now, it's still in the prototype stage. But you can see full documentation at [https://docs.onecthr.ee/fusion](https://docs.onecthr.ee/fusion).

## Available Features (for yet)

<h4>
- Routing*<br />
- Templating Engine*<br />
- Container Service (for DI)*<br />
</h4>

<h5>* Current version is <i>alpha-prototype</i> and unoptimized.