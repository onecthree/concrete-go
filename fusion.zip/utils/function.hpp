#pragma once

#define SKIPF() ( void() )